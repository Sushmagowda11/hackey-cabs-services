

(function ($) {
	"use strict";

	jQuery(document).ready(function ($) {


		/* 
		=================================================================
		masked input JS
		=================================================================	
		*/
		$('#lightgallery').lightGallery({
			selector: '.col-lg-4'
		});


	});


}(jQuery));

